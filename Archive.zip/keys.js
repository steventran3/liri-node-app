console.log('this is loaded');

var twitterKeys = {
  consumer_key: 'H8lRWrYGPyZr4FXw5Z1kr5Jcd',
  consumer_secret: 'mwfwRA7HGLOxKXbIxzIisa6lbvm1Gx6uWErH6wG4FQDd6VEQqP',
  access_token_key: '939996438775218176-aJgpdqMUVCFMpwtjixawCXKQRo3hxml',
  access_token_secret: 'VVUgEUHQV0orG1U6WDDZuF7owxIcZz0g4Ri3xK6cqq4Vz',
}

var spotifyKeys = {
  client_id: 'bc40a0bfe33d4840929d142328f26b9b',
  client_secret: '2d98bed2b2fc4d7ea14fbaeaaf669668'
}

module.exports = 
  twitterKeys,
  spotifyKeys

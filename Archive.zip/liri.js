var twitterApi = require('./keys.js')
var spotifyApi = require('./keys.js')
var Twitter = require('twitter');
var Spotify = require('node-spotify-api');
var request = require('request');
var fs = require('fs')
var command = process.argv[2];


if (command == 'my-tweets') {
  
  var client = new Twitter({
    consumer_key: twitterApi.consumer_key,
    consumer_secret: twitterApi.consumer_secret,
    access_token_key: twitterApi.access_token_key,
    access_token_secret: twitterApi.access_token_secret
   });
  
   var params = {screen_name: 'steventran_3'}; 
  
   client.get('statuses/user_timeline', params, function(err, tweets, response) {
    
    if (err) {
      console.log(err);
    }
    else { 
      for (var i = 0; i <= 19; i++) {
       console.log('Tweeted: ', tweets[i].text)
       console.log('Time Tweeted: ', tweets[i].created_at)
       console.log('--------------------------------------')
      } 
    }
   });

} 
else if (command == 'spotify-this-song') {
  
  var spotify = new Spotify({
    id: 'bc40a0bfe33d4840929d142328f26b9b',
    secret: '2d98bed2b2fc4d7ea14fbaeaaf669668'
   });
  var nodeArg = process.argv
  var songName = '';

  for (var i = 3; i < nodeArg.length; i++) {
    songName += nodeArg[i] + ' ';
  }
  spotify.search({ type: 'track', query:songName}, function(err, data) {
    if (err) {
      return console.log('Error occurred: ' + err);
    } 
   console.log(data); 
   });

} 
else if (command == 'movie-this') {
  
  var nodeArg1 = process.argv
  var movieName = '';
  
  for (var i = 3; i < nodeArg1.length; i++) {
    movieName += nodeArg1[i] + ' ';
  }
  
  request("https://www.omdbapi.com/?t=" + movieName + "&y=&plot=short&apikey=40e9cece", function (err, response, body) {
    // console.log('error:', err); // Print the error if one occurred
    // console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
    console.log('body:', JSON.parse(body)); // Print the HTML for the Google homepage.
    console.log('Movie Title: ' + body.Title)
  });

}
else if (command == 'do-what-it-says') {
  
  fs.readFile('random.txt', 'utf8', function (err, data){
    console.log(data)
  });

}
